import org.example.rectangle;
import org.junit.jupiter.api.*;

class rectangleTest {

    rectangle rectangle1 = new rectangle(5, 4);
    rectangle rectangle2 = new rectangle(10, 20);


    @Test
    @DisplayName("Test getArea #1")
    public void getArea() {
        Assertions.assertEquals(20, rectangle1.getArea());
    }

    @Test
    @DisplayName("Test getArea #2")
    public void getArea2() {
        Assertions.assertNotEquals(18, rectangle1.getArea());
    }

    @Test
    public void getPerimeter() {
        Assertions.assertEquals(18, rectangle1.getPerimeter());
    }

    @Test
    public void getPerimeter2() {
        Assertions.assertNotEquals(20, rectangle1.getPerimeter());
    }
}
